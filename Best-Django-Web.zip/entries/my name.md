# my name is Hafsa

---
- p
- p
1. cd
2. cd