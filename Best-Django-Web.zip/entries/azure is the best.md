# IS Azure the best ????

> my answer is no 

---

## why is your answer No ?
- Cause I don't like the name !!!